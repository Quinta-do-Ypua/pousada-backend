import{cg as o}from"./main-DyQuHL02.js";const e=t=>r=>r&&o(t,r)||"—";export{e as t};
//# sourceMappingURL=translationFormatter-o5FSSs8x.js.map
