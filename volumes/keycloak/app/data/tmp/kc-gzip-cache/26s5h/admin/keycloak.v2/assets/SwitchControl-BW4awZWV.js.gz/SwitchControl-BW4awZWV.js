import{jsx as a}from"react/jsx-runtime";import{a as r,$ as n}from"./main-DyQuHL02.js";const l=t=>{const{t:o}=r();return a(n,{...t,labelOn:o("on"),labelOff:o("off")})};export{l as D};
//# sourceMappingURL=SwitchControl-BW4awZWV.js.map
