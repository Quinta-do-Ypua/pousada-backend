import{cX as r}from"./main-DyQuHL02.js";const s={dateStyle:"long",timeStyle:"short"};function c(){const{whoAmI:t}=r();return function(o,e){return o.toLocaleString(t.locale,e)}}export{s as F,c as u};
//# sourceMappingURL=useFormatDate-x3o3_1Y5.js.map
