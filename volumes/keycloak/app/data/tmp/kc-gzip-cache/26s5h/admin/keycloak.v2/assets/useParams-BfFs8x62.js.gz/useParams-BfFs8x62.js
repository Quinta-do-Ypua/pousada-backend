import{c as s}from"./main-DyQuHL02.js";const r=()=>s();export{r as u};
//# sourceMappingURL=useParams-BfFs8x62.js.map
